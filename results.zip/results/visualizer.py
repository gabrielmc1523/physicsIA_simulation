import json
import math
import subprocess
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

def loggalogga(x, y, base=10):
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)

    if np.any(x <= 0) or np.any(y <= 0):
        raise ValueError("All x and y values must be positive for log-log fitting.")

    if base == 10:
        X = np.log10(x)
        Y = np.log10(y)
    elif base == 'e':
        X = np.log(x)
        Y = np.log(y)
    else:
        raise ValueError("base must be 10 or 'e'")

    k, b = np.polyfit(X, Y, 1)
    print(f"$t(m) = 10^{'{'}{b:.2f}{'}'}x^{'{'}{k:.2f}{'}'}$")
    # t(m) = 10^b/m
    # 10^10 = 10^b/m
    # m = 10^b/10^10
    # m = 10^(b - 10)
    print(f"m_0: $10^{b-10}$")

def draw_ellipses(a_i, e_i, a_f, e_f, m, num_points=2000):
    # Deduce star radius
    R_star = 696340000
    R_core = 696340000 * 0.2

    def ellipse_points(a, e):
        theta = np.linspace(0, 2*np.pi, num_points)
        r = a * (1 - e**2) / (1 + e * np.cos(theta))
        x = r * np.cos(theta)
        y = r * np.sin(theta)
        return x, y

    x_i, y_i = ellipse_points(a_i, e_i)
    x_f, y_f = ellipse_points(a_f, e_f)

    fig, ax = plt.subplots()

    # Star (filled light orange)
    star = plt.Circle((0, 0), R_star, color='orange', alpha=0.3,
                      label="Star")
    ax.add_patch(star)

    # Core
    core = plt.Circle((0, 0), R_core, fill=False, linewidth=2,
                      label=r"Core $\approx 0.2R_{\odot}$")
    ax.add_patch(core)

    # Orbits
    ax.plot(x_i, y_i, label="Initial Orbit")
    ax.plot(x_f, y_f, label="Final Orbit")

    # Star center dot
    ax.scatter(0, 0, s=20, label="Star Center", color="orange")

    ax.set_aspect('equal', adjustable='box')
    ax.set_xlim(-R_star*1.1*max(2*a_i/R_star, 1), R_star*1.1)
    ax.set_ylim(-R_star*1.1*max(a_i*math.sqrt(1 - e_i ** 2)/R_star, 1), R_star*1.1*max(a_i*math.sqrt(1 - e_i ** 2)/R_star, 1))

    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_title(rf"Orbital Decay of $10^{{{int(math.log10(m))}}}$ kg PBH Inside Star")

    if len(sys.argv) < 4:
        ax.legend()


    plt.show()

def main(path):
    with open(path, "r") as f:
        data = json.load(f)
        fig, ax = plt.subplots()
        time_unit = "years"
        x = data["time"]
        if x <= 1e-3:
            x *= 1e6
            time_unit = "microseconds"
        elif x <= 1:
            x *= 1e3
            time_unit = "milliseconds"
        elif x <= 86400:
            time_unit = "seconds"
        elif x <= 3.154e7:
            x /= 86400
            time_unit = "days"
        else: 
            x /= 3.154e7
            time_unit = "years"
        
        ax.plot(x, data[""])
        ax.set_xlabel(f"Time in {time_unit}")
        ax.set_ylabel("Semi-major axis in meters")
        exponent = int(np.floor(np.log10(data["pbh_mass"][0])))
        ax.set_title(rf"Semi-major axis of the orbit of a $10^{{{exponent}}}$ kilogram PBH")
        plt.show()
        plt.close()

        fig, ax = plt.subplots()
        ax.plot(x, data["eccentricity"])
        ax.set_xlabel(f"Time in {time_unit}")
        ax.set_ylabel("Eccentricity")
        ax.set_title(rf"Eccentricity of the orbit of a $10^{{{exponent}}}$ kilogram PBH")
        plt.show()
        plt.close()

        fig, ax = plt.subplots()
        ax.plot(x, data["pbh_mass"])
        ax.set_xlabel(f"Time in {time_unit}")
        ax.set_ylabel("Mass of the PBH in kilograms")
        ax.set_title(rf"Mass of a $10^{{{exponent}}}$ kilogram PBH as it orbits a sun-like star")
        plt.show()
        plt.close()

        fig, ax = plt.subplots()
        ax.plot(x, data["sun_mass"])
        ax.set_xlabel(f"Time in {time_unit}")
        ax.set_ylabel("Mass of the star in kilograms")
        ax.set_title(rf"Mass of a sun-like star as a $10^{{{exponent}}}$ kilogram PBH orbits it")
        plt.show()
        plt.close()

        fig, ax = plt.subplots()
        ax.plot(x, data["distances"])
        ax.set_xlabel(f"Time in {time_unit}")
        ax.set_ylabel("Perifocal distance in meters")
        ax.set_title(rf"Perifocal distance of the orbit of a $10^{{{exponent}}}$ kilogram PBH as it orbits a sun-like star")
        plt.show()
        plt.close()

def w_all(data_type, data_name, data_unit):
    x = []
    time_unit = "years"
    time_factor = 1
    fig, ax = plt.subplots()
    ax.set_xlabel(f"Time in {time_unit}")
    if data_type == "eccentricity":
        ax.set_ylabel("Eccentricity")
    else:
        ax.set_ylabel(f"{data_name} in {data_unit}")
    ax.set_title(rf"{data_name} {f"({data_unit})" if data_type != "eccentricity" else ""} as a function of the mass of the PBH (kg)")
    for path in os.listdir(os.getcwd()):
        if str(path).split('.')[-1] != "json":
            continue
        with open(path, "r") as f:
            data = json.load(f)
            print(f"x: {x}")
            print(f"y: {data[data_type]}")
            if len(x) == 0:
                x = np.array(data["time"])
                time_unit = "years"
                if x[-1] <= 1e-3:
                    x *= 1e6
                    time_factor = 1e6
                    time_unit = "microseconds"
                elif x[-1] <= 1:
                    x *= 1e3
                    time_factor = 1e3
                    time_unit = "milliseconds"
                elif x[-1] <= 86400:
                    time_unit = "seconds"
                elif x[-1] <= 3.154e7:
                    x /= 86400
                    time_factor = 1/86400
                    time_unit = "days"
                else: 
                    x /= 3.154e7
                    time_factor = 1 / 3.154e7
                    time_unit = "years"
            else:
                x = np.array(data["time"]) * time_factor

            ax.plot(x, data[data_type], label=f"{data["pbh_mass"][0]} kg")
    ax.legend()
    plt.show()

def b_all(data_type, data_name, data_unit, a, e):
    x = []
    y = []
    colors = []
    fig, ax = plt.subplots()
    ax.set_xlabel(f"Mass of the PBH in kilograms")
    if data_type == "e":
        ax.set_ylabel("Final Eccentricity")
    else:
        ax.set_ylabel(f"Final {data_name} in {data_unit}")
    ax.set_title(rf"{'Final' if data_type != 'time' else ''} {data_name} {f'({data_unit})' if data_type != 'eccentricity' else ''} as a function of the mass of the PBH (kg)")
    for path in os.listdir(os.getcwd() + (f"/{a}_{e}")):
        if str(path).split('.')[-1] != "json":
            continue
        if '+' not in path:
            subprocess.run(["mv", f"{a}_{e}/{path}" , f"{a}_{e}/1e+{int(math.log10(int(path.split('.')[0])))}.json"])
            path = f"1e+{int(math.log10(int(path.split('.')[0])))}.json"
        with open(f"{a}_{e}/{path}", "r") as f:
            data = json.load(f)
            x.append(data["initial m"])
            if data_type == "time":
                t = data["time"] / 3.154e7
                y.append(t)
            else:
                y.append(data[f"final {data_type}"])
    print(x)
    x, y = zip(*sorted(zip(x, y), key=lambda pair: int(pair[0])))
    x = list(x)
    y = list(y)
    ax.set_xscale("log")
    done = False
    if data_type == "time":
        for i in range(len(y)):
            if y[i] > 1e10:
                colors.append("red")
            else:
                colors.append("blue")
                if not done:
                    loggalogga(x[i:], y[i:])
                    done = True
    if data_type in ["time"]:
        ax.set_yscale("log")
    ax.plot(x, y, zorder=1, color="blue")
    ax.scatter(x, y, color=colors, zorder=2)
    
    plt.show()

if __name__ == "__main__":
    arg = sys.argv[1]
    if arg.split('.')[-1] == "json":
        main(arg)
    elif arg == "pbh_mass":
        w_all("pbh_mass", "PBH Mass", "kilograms")
    elif arg == "sun_mass":
        w_all("sun_mass", "Star Mass", "kilograms")
    elif arg == "a":
        w_all("semi-major axis", "Semi-Major Axis", "meters")
    elif arg == "e":
        w_all("eccentricity", "Eccentricity", None)
    elif arg == "distance":
        w_all("distances", "Distance from the core of the star", "meters")
    elif arg == "-b":
        arg2 = sys.argv[2]
        a = sys.argv[3]
        e = sys.argv[4]
        if arg2 == "m":
            b_all("m", "PBH Mass", "kilograms", a, e)
        elif arg2 == "M":
            b_all("M", "Star Mass", "kilograms", a, e)
        elif arg2 == "a":
            b_all("a", "Semi-Major Axis", "meters", a, e)
        elif arg2 == "e":
            b_all("e", "Eccentricity", None, a, e)
        elif arg2 == "time":
            b_all("time", "Time to reach the core of the star", "years", a, e)
    elif arg == "-e":
        with open(sys.argv[2], "r") as f:
            data = json.load(f)
            initial_a = data["initial a"]
            final_a = data["final a"]
            initial_e = data["initial e"]
            final_e = data["final e"]
            draw_ellipses(initial_a, initial_e, final_a, final_e, data["initial m"])
